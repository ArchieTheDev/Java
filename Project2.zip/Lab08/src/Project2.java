/*
 * Author: Morgan Coker
 * Date: October 10, 2023
 * Description: Lab08; game of 21
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */

import java.util.Random;
import java.util.Scanner;

class Player {
    private Die die1 = new Die();
    private Die die2 = new Die();
    private int score;

    public void rollDice() {
        // Roll two dice and update the player's score
        die1.roll();
        die2.roll();
        score += die1.getValue() + die2.getValue();
    }

    public int getScore() {
        // Get the player's current score
        return score;
    }

    public void resetScore() {
        // Reset the player's score to 0
        score = 0;
    }
}

class Die {
    private Random random = new Random();
    private int value;

    public void roll() {
        // Simulate rolling a six-sided die and set the value
        value = random.nextInt(6) + 1;
    }

    public int getValue() {
        // Get the current value of the die
        return value;
    }
}

// Gameplay
public class Project2 {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			Player player = new Player();
			Player computer = new Player();

			while (true) {
			    player.resetScore();
			    computer.resetScore();

			    while (true) {
			        System.out.println("Player's Turn:");
			        System.out.print("Roll the dice? (yes/no): ");
			        if (scanner.nextLine().equalsIgnoreCase("yes")) {
			            // Player chooses to roll the dice
			            player.rollDice();
			            int playerScore = player.getScore();
			            System.out.println("Player's score: " + playerScore);

			            if (playerScore > 21) {
			                // Player has busted
			                System.out.println("Player busted!");
			                break;
			            }
			        } else {
			            // Player chooses not to roll the dice
			            break;
			        }
			    }

			    while (computer.getScore() <= player.getScore() && computer.getScore() <= 21) {
			        // Computer's turn: Roll until the computer's score is greater than the player's or it busts
			        computer.rollDice();
			    }

			    int playerScore = player.getScore();
			    int computerScore = computer.getScore();
			    System.out.println("Player's score: " + playerScore);
			    System.out.println("Computer's score: " + computerScore);

			    if (playerScore > 21 || (computerScore <= 21 && computerScore > playerScore)) {
			        // Determine the winner based on scores
			        System.out.println("Computer wins!");
			    } else if (computerScore > 21 || (playerScore <= 21 && playerScore > computerScore)) {
			        System.out.println("Player wins!");
			    } else {
			        System.out.println("It's a tie!");
			    }

			    System.out.print("Play again? (yes/no): ");
			    if (!scanner.nextLine().equalsIgnoreCase("yes")) {
			        // Check if the player wants to play another round
			        break;
			    }
			}
		}
        System.out.println("Thanks for playing!");
    }
}
