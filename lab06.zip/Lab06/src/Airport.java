/*
 * Author: Morgan Coker
 * Date: September 25, 2023
 * Description: Airport distance calculator
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */

import java.util.Scanner;

public class Airport {
    private double latitude, longitude;

    public Airport(double lat, double lon) {
        setLatitude(lat);
        setLongitude(lon);
    }

    public static double calcDistance(double lat1, double lon1, double lat2, double lon2) {
        double r = 10800.0 / Math.PI;
        double d = Math.toRadians(lat1);
        double e = Math.toRadians(lon1);
        double f = Math.toRadians(lat2);
        double g = Math.toRadians(lon2);
        double h = Math.acos(Math.sin(d) * Math.sin(f) + Math.cos(d) * Math.cos(f) * Math.cos(e - g));
        return r * h;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter coordinates for the origin (Lat, Long):");
        double latOrigin = scanner.nextDouble();
        double lonOrigin = scanner.nextDouble();

        System.out.println("Enter coordinates for the destination (Lat, Long):");
        double latDestin = scanner.nextDouble();
        double lonDestin = scanner.nextDouble();

        double distanceNM = calcDistance(latOrigin, lonOrigin, latDestin, lonDestin);
        double distanceSM = distanceNM * 1.15;

        System.out.printf("Distance: %.1f NM%n", distanceNM);
        System.out.printf("Distance: %.1f SM%n", distanceSM);

        scanner.close();
    }

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
}
