/* Author: Ashton Coker
 * Date: August 22, 2023
 * Description: Java file created for Lab 01, used to provide the output of "JAVA" through asterisks and spaces.
 */
public class JAVAoutput {

	public static void main(String[] args) {
		System.out.println("    ****  *****  ** **  *****");
		System.out.println("     **   ** **  ** **  ** **");
		System.out.println("     **   ** **  ** **  ** **");
		System.out.println("  ** **   *****   ****  *****");
		System.out.println("   ***    ** **    **   ** **");
	} 

}
