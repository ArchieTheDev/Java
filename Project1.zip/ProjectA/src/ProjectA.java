/*
 * Author: Morgan Coker
 * Date: September 10, 2023
 * Decription: Time conversion from seconds to days
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, and Java 2 quick reference pamphlet.
 * Notes for self: While initially building and receiving output in DD:HH:MM:SS format, the user input number: "Seconds" would not populate correctly in the output.
 * The output would provide a number of seconds that had been already manipulated by the code therefore, providing an incorrect echo of user input.
 * Fix Action: Add a new variable "OriginalSeconds" that would stay a constant and echo itself in the output.
 */

import java.util.Scanner;

public class ProjectA {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char continueInput;

        do {
            // Define constants for seconds
            int SecondsInMinute = 60;
            int SecondsInHour = 3600;
            int SecondsInDay = 86400;

            // Define variables; added OriginalSeconds variable for output
            int Seconds, OriginalSeconds, Days, Hours, Minutes, RemainingSeconds;

            // User input
            System.out.print("Enter the number of seconds: ");
            OriginalSeconds = scanner.nextInt();
            Seconds = OriginalSeconds;

            // Calculate the number of days, hours, minutes, and seconds
            Days = Seconds / SecondsInDay;
            Seconds = Seconds % SecondsInDay;
            Hours = Seconds / SecondsInHour;
            Seconds = Seconds % SecondsInHour;
            Minutes = Seconds / SecondsInMinute;
            RemainingSeconds = Seconds % SecondsInMinute;

            // Display the input and descriptive time calculation
            System.out.print("You entered " + OriginalSeconds + " seconds, which is ");

            if (Days > 0) {
                System.out.print(Days + " day");
                if (Days > 1) {
                    System.out.print("s");
                }
                System.out.print(", ");
            }

            if (Hours > 0 || Days > 0) {
                System.out.print(Hours + " hour");
                if (Hours > 1) {
                    System.out.print("s");
                }
                System.out.print(", ");
            }

            if (Minutes > 0 || Hours > 0 || Days > 0) {
                System.out.print(Minutes + " minute");
                if (Minutes > 1) {
                    System.out.print("s");
                }
                System.out.print(", ");
            }

            System.out.print(RemainingSeconds + " second" + (RemainingSeconds != 1 ? "s" : ""));

            // Format the output as (X days HH:MM:SS)
            System.out.printf(" (%d days %02d:%02d:%02d)", Days, Hours, Minutes, RemainingSeconds);
            System.out.println();

            // Loop
            System.out.print("Do you want to enter another number of seconds? (y/n): ");
            continueInput = scanner.next().toLowerCase().charAt(0);
        } while (continueInput == 'y');

        scanner.close();
    }
}


