/*
 * Author: Morgan Coker
 * Date: September 18, 2023
 * Description: Airport Coordinates - San Diego
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */


public class Airport {
    private String identifier;
    private double latitude, longitude;
    private Double magneticVariation, elevation;

    public Airport(String id, double lat, double lon, Double magVar, Double elev) {
        identifier = id;
        latitude = lat;
        longitude = lon;
        magneticVariation = magVar;
        elevation = elev;
    }

    public String getIdentifier() { return identifier; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }
    public Double getMagneticVariation() { return magneticVariation; }
    public Double getElevation() { return elevation; }

    public void setIdentifier(String id) { identifier = id; }
    public void setLatitude(double lat) { latitude = lat; }
    public void setLongitude(double lon) { longitude = lon; }
    public void setMagneticVariation(Double magVar) { magneticVariation = magVar; }
    public void setElevation(Double elev) { elevation = elev; }

    @Override
    public String toString() {
        return String.format("ID: %s, Lat: %.6f, Long: %.6f, Var: %.1f, Elev: %.1f'", 
            identifier, latitude, longitude, magneticVariation, elevation);
    }

    public static void main(String[] args) {
        Airport SanDiego = new Airport("SAN", 32.7335556, -117.1896667, 14.0, 16.8);
        System.out.println(SanDiego);
    }
}
