public class Main {
    public static void main(String[] args) {
        Airport airport1 = new Airport(32.7336, -117.1897); // Create Airport object using constructor with two doubles
        Airport airport2 = new Airport(0, 0); // Create Airport object using default constructor

        airport2 = new Airport(40.6398, -73.7789); // Set the latitude and longitude for the second airport

        double distance1 = airport1.calcDistance(airport2); // Calculate distance between airports
        double distance2 = airport1.calcDistance(40.7128, -74.0060); // Calculate distance to another point

        // Display the distances
        System.out.println("Distance between airports: " + distance1 + " nautical miles");
        System.out.println("Distance from the first airport to another point: " + distance2 + " nautical miles");
    }
}
