/*
 * Author: Morgan Coker
 * Date: October 23, 2023
 * Description: Airport round 2, lab9
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */


public class Airport {
    private String identifier;
    private double latitude, longitude;
    private Double magneticVariation, elevation;

    public Airport(String id, double lat, double lon, Double magVar, Double elev) {
        this.identifier = id;
        this.latitude = lat;
        this.longitude = lon;
        this.magneticVariation = magVar;
        this.elevation = elev;
    }

    public Airport(double lat, double lon) {
        this.latitude = lat;
        this.longitude = lon;
    }

    public double calcDistance(Airport destination) {
        return calcDistance(this.latitude, this.longitude, destination.latitude, destination.longitude);
    }

    public double calcDistance(double destLat, double destLon) {
        return calcDistance(this.latitude, this.longitude, destLat, destLon);
    }

    private static double calcDistance(double lat1, double lon1, double lat2, double lon2) {
        double r = 10800.0 / Math.PI;
        double d = Math.toRadians(lat1);
        double e = Math.toRadians(lon1);
        double f = Math.toRadians(lat2);
        double g = Math.toRadians(lon2);
        return r * Math.acos(Math.sin(d) * Math.sin(f) + Math.cos(d) * Math.cos(f) * Math.cos(e - g));
    }

    @Override
    public String toString() {
        return String.format("ID: %s, Lat: %.6f, Long: %.6f, Var: %.1f, Elev: %.1f'",
            identifier, latitude, longitude, magneticVariation, elevation);
    }

    public static void main(String[] args) {
        Airport sanDiego = new Airport("SAN", 32.7335556, -117.1896667, 14.0, 16.8);
        System.out.println(sanDiego);

        Airport newAirport = new Airport(40.7128, -74.0060);
        double distance = sanDiego.calcDistance(newAirport);
        System.out.println("Distance to another point: " + distance + " nautical miles");
    }
}
