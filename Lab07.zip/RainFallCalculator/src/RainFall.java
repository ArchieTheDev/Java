/*
 * Author: Morgan Coker
 * Date: October 1, 2023
 * Description: Rain Fall Calculator
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */


import java.util.Scanner;

public class RainFall {
    private double[] monthlyRainfall = new double[12];
    private String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    public void inputMonthlyRainfall() {
        try (Scanner scanner = new Scanner(System.in)) {
			for (int i = 0; i < 12; i++) {
			    do {
			        System.out.print("Enter rainfall in inches for " + monthNames[i] + ": ");
			        while (!scanner.hasNextDouble()) scanner.next();
			        monthlyRainfall[i] = scanner.nextDouble();
			    } while (monthlyRainfall[i] < 0);
			}
		}
    }

    public double totalRainfall() {
        double total = 0;
        for (double rainfall : monthlyRainfall) total += rainfall;
        return total;
    }

    public double averageMonthlyRainfall() {
        return totalRainfall() / 12;
    }

    public String monthWithMostRain() {
        int maxIndex = 0;
        for (int i = 1; i < 12; i++) if (monthlyRainfall[i] > monthlyRainfall[maxIndex]) maxIndex = i;
        return monthNames[maxIndex];
    }

    public String monthWithLeastRain() {
        int minIndex = 0;
        for (int i = 1; i < 12; i++) if (monthlyRainfall[i] < monthlyRainfall[minIndex]) minIndex = i;
        return monthNames[minIndex];
    }

    public static void main(String[] args) {
        RainFall analyzer = new RainFall();
        analyzer.inputMonthlyRainfall();
        System.out.println("Total annual rainfall: " + analyzer.totalRainfall() + " inches");
        System.out.println("Average monthly rainfall: " + analyzer.averageMonthlyRainfall() + " inches");
        System.out.println("Month with the most rain: " + analyzer.monthWithMostRain());
        System.out.println("Month with the least rain: " + analyzer.monthWithLeastRain());
    }
}
