/*
 * Author: Morgan Coker
 * Date: October 17, 2023
 * Description: Lab08; Proper Case. Make the first letter of each word uppercase while leaving the following characters in the string lowercase.
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, Java 2 quick reference pamphlet, and https://stackoverflow.com/
 */

import java.util.Scanner;

public class ProperCase {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.print("Enter a string (or '!q' to quit): ");
                String inputString = scanner.nextLine();

                if (inputString.equals("!q")) {
                    break;
                }

                System.out.println("Proper Case: " + convertToProperCase(inputString));
            }
        }
    }

    public static String convertToProperCase(String input) {
        if (input == null || input.isEmpty()) return input;

        String[] words = input.split(" ");
        StringBuilder result = new StringBuilder();

        for (String word : words) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }

        if (result.length() > 0) result.setLength(result.length() - 1);
        return result.toString();
    }
}
