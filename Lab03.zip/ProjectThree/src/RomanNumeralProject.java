

/* Author: Morgan Coker
 * Date: September 8, 2023
 * Description: Lab3, Arabic numerals to Roman numerals conversion. 
 * References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, and Java 2 quick reference pamphlet.
 */

import java.util.Scanner;

public class RomanNumeralProject {
	
	//Assign Roman numerals
	public static String Conversion(int number) {
		String[] RomanNumerals = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
		return RomanNumerals[number - 1];
		}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		char AnotherEntry = 'Y';

		while (AnotherEntry == 'Y' || AnotherEntry == 'y') {      
			int number = 0; // Default value
		           
			// Validate input (numbers 1-10 only)
			while (true) {
				System.out.print("Enter a number between 1 and 10: ");
				if (scanner.hasNextInt())
					number = scanner.nextInt();
					scanner.nextLine();
		                
				if (number >= 1 && number <= 10) {
					break; // Exit the loop if a valid number is entered
				} else {
						System.out.println("Invalid input. Please enter a number between 1 and 10.");
						scanner.next();
						scanner.nextLine(); // Clear the invalid input
				}
			}

			//Format and display corresponding Roman numeral to input
			String RomanNumeral = Conversion(number);
			System.out.println("Corresponding Roman numeral: " + RomanNumeral);
			scanner.nextLine();
		
			System.out.print("Do you want to input another number (Y/N)? ");
			AnotherEntry = scanner.nextLine().charAt(0);
		}
		
		scanner.close();
	}
}
	
