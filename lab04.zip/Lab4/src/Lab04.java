
/*
 * Author: Morgan Coker
 * Date: September 15, 2023
 * Description: Prime number writer
 * References: References used: Youtube.com, https://www.w3schools.com/js/default.asp and sub-directories, and Java 2 quick reference pamphlet.
 */

import java.io.FileWriter;
import java.io.IOException;
// Required to write to file

public class Lab04 {

	 public static void main(String[] args) {
	        int low = 1, high = 1000;
	        String filePath = "C:\\Users\\ashto\\Desktop\\PrimeNumbers.txt"; 
	        				// Local file path - will differ with each user
	        try (FileWriter writer = new FileWriter(filePath)) {
	            while (low < high) {
	                boolean flag = false;
	                for (int i = 2; i <= low / 2; ++i) {
	                    if (low % i == 0) {
	                        flag = true;
	                        break;
	                    }
	                }

	                if (!flag && low != 0 && low != 1) {
	                    // Write prime numbers to the file
	                    writer.write(low + " is a prime number.\n");
	                }
	                ++low;
	            }
	            System.out.println("Prime numbers up to 1000 have been written to " + filePath);
	        } catch (IOException e) {
	            System.err.println("Error writing to the file: " + e.getMessage());
	        }
	    }
	}
